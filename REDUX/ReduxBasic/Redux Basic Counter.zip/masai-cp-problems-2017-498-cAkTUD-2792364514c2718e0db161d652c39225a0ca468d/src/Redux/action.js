//DO NOT change the function names

//function to return the add action object
const handleAddActionObj = () => {};

//function to return the reduce action object
const handleReduceActionObj = () => {};

export { handleAddActionObj, handleReduceActionObj };
