import React from "react";

const CounterValue = () => {
  return <div data-testid="counterValue"></div>;
};

export default CounterValue;
