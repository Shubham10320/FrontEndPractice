//Complete the reducer function logic inside the curly braces {}
// the counter initstate shouldbe 10
const counterReducer = () => {};

export { counterReducer };
