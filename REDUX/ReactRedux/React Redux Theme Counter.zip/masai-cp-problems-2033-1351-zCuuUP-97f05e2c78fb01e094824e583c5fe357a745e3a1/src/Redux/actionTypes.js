//DO NOT modify this file
export const ADD = "ADD";
export const REDUCE = "REDUCE";
export const CHANGE_THEME = "CHANGE_THEME";
