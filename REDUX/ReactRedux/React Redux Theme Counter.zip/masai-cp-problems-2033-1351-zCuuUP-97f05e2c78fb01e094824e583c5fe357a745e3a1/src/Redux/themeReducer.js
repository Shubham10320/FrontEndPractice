//Complete the reducer function logic inside the curly braces {}
// the theme initstate shouldbe light
const themeReducer = () => {};

export { themeReducer };
