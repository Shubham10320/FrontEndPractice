//DO NOT change the function names

import { ADD, REDUCE, CHANGE_THEME } from "./actionTypes";

const handleAdd = () => {};

const handleReduce = () => {};
const handleTheme = () => {};

export { handleAdd, handleReduce, handleTheme };
