import React from 'react'

const AllRoutes = () => {
    return (
        <div></div>
    )
}

export {AllRoutes}
