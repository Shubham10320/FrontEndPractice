import * as types from "./actionType";

const initialState = {
  
};

const reducer = (state = initialState) => {
  return state
};

export { reducer };