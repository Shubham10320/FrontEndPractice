
function App() {
  // DO NOT CHANGE/MODIFY this app-structure here
  return (
    <div data-testid="data-app">
    </div>
  );
}

export default App;
