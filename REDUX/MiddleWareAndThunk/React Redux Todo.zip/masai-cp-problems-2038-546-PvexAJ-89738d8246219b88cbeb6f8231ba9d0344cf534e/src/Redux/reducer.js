
const initialState = {
  todos: [],
  isLoading: false,
  isError: false,
};

//complete the reducer function 
const reducer = (state = initialState) => {
  return state;
};

export { reducer };
