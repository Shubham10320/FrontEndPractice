import "./App.css";

function App() {
  return (
    <div className="App">
      {/* Add the Todo component here */}
    </div>
  );
}

export default App;
