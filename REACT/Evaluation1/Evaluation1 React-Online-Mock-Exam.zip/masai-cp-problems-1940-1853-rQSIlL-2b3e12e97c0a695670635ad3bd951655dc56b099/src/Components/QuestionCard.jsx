const QuestionCard = () => {
  return (
    <div className="question-card">
      {/* add question here */}

      <div className="options"></div>
      <div className="show-ans"></div>
    </div>
  );
};

export default QuestionCard;
