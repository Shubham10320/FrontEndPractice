const Option = () => {
  return <div data-testid="option">{/* create a button here */}</div>;
};

export default Option;
