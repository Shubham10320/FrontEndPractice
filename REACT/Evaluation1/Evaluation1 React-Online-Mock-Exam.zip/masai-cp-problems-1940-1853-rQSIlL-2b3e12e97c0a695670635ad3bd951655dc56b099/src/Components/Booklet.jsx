const Booklet = () => {
  return (
    <div data-testid="Booklet">
      {/* create a div with className="welcome-div" here*/}

      <div className="questions-container">
        {/* Append score and question card components here */}
      </div>
    </div>
  );
};

export default Booklet;
