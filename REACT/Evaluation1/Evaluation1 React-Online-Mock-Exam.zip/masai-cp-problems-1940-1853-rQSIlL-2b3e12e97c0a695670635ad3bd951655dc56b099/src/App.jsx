import "./App.css";
function App() {
  return <div className="App">{/* import Booklet component here */}</div>;
}

export default App;
