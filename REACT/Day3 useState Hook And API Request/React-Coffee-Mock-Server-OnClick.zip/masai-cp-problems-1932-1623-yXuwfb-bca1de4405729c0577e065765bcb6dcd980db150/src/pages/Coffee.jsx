import React from "react";

const Coffee = () => {
  return (
    <div>
      {/* Create Button `Get Coffee` here */}

      <div className="coffee_container">
        {/* Populate coffee data inside CoffeeCard.jsx */}
      </div>
    </div>
  );
};

export default Coffee;
