const App = () => {
  return (
    <div>
      {/* Add h1 tag here as per the problem statement */}
      {/* Add components here MobileInfo, Courses, Users here */}
    </div>
  );
};

export default App;
