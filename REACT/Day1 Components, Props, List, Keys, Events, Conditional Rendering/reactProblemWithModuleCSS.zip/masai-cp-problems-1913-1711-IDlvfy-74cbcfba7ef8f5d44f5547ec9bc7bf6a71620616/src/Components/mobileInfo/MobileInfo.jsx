const MobileInfo = () => {
  return <div data-testid="mobile_info"></div>;
};
export default MobileInfo;
