const Courses = () => {
  return <div data-testid="courses"></div>;
};

export default Courses;
