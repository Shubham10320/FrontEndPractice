function CountriesCard() {
  return (
    <tr data-testid="country-card">
      <td></td>
      <td data-testid="country-card-name"></td>
      <td data-testid="country-card-population"></td>
      <td></td>
    </tr>
  );
}

export default CountriesCard;
