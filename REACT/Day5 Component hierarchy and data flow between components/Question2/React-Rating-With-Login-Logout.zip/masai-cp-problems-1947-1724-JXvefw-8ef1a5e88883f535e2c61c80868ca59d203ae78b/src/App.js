const App = () => {
  return (
    <div className="App">
      {/* Either Dashboard or Login component should be visible at a time */}
    </div>
  );
};

export default App;
