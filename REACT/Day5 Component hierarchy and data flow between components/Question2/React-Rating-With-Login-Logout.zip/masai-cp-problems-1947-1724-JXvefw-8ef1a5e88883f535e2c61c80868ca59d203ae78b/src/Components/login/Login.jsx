const Login = () => {
  return (
    <div>
      <form>
        <input type="text" placeholder="username" name="username" />
        <input type="text" placeholder="password" name="password" />
        <input type="submit" value="submit" />
      </form>
    </div>
  );
};

export default Login;
