import React from "react";
import { FaStar } from "react-icons/fa";

const Star = () => {
  return <FaStar data-icon="star" />;
};
export default Star;
