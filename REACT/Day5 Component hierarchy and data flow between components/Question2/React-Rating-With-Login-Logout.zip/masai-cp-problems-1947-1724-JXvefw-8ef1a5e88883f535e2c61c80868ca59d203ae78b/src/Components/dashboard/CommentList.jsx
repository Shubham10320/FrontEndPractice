import React from "react";

const CommentList = () => {
  return (
    <>{/* Add you comments with the help of Comment component using map */}</>
  );
};
export default CommentList;
