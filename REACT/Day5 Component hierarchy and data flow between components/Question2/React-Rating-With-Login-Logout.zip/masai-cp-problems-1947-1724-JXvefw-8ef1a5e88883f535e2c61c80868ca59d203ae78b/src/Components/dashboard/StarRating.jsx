const StarRating = () => {
  return (
    <>
      {/* Add stars here with the help of Star component */}

      {/* add p tag here in this format {selectedStars} of {totalStars} like 1 of 5*/}
    </>
  );
};
export default StarRating;
