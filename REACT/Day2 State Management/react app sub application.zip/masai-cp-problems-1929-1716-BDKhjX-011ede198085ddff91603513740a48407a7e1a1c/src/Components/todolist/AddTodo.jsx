function AddTodo() {
  return (
    <div>
      {/* Add a input tag here and a button to "ADD" with the help of `Button` component */}
    </div>
  );
}

export default AddTodo;
