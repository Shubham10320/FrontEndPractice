function UserCard() {
  return <div data-testid="user-card"></div>;
}

export default UserCard;
