function Button() {
  return <button data-testid="common-button">{}</button>;
}

export default Button;
