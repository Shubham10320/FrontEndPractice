function Container() {
  return <div data-testid="common-container">{}</div>;
}

export default Container;
