function Counter() {
  return (
    <>
      {/* You can wrap all the elements in such a way that `Container` component will act like a parent div */}
      <h1>Count : {}</h1>
      <div>
        {/* Add 3 buttons for INC, DEC, RESET using Button component */}
      </div>
    </>
  );
}

export default Counter;
